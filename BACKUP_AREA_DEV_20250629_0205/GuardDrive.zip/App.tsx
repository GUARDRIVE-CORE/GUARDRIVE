import React from 'react';
import './App.css';
import { 
  Shield, 
  Leaf, 
  Coins, 
  Truck, 
  BarChart3, 
  CheckCircle, 
  ArrowRight, 
  Play,
  Star,
  Users,
  Globe,
  Zap,
  Lock,
  TrendingUp,
  Award,
  Phone,
  Mail,
  MapPin
} from 'lucide-react';

// Header Component
const Header = () => {
  return (
    <header className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b border-gray-100 z-50">
      <div className="container-custom">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-2">
            <Shield className="h-8 w-8 text-gradient-primary" />
            <span className="text-xl font-bold text-gradient-primary">GuardDrive FleetShield</span>
          </div>
          
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#features" className="text-gray-600 hover:text-gray-900 transition-colors">Recursos</a>
            <a href="#benefits" className="text-gray-600 hover:text-gray-900 transition-colors">Benefícios</a>
            <a href="#pricing" className="text-gray-600 hover:text-gray-900 transition-colors">Preços</a>
            <a href="#contact" className="text-gray-600 hover:text-gray-900 transition-colors">Contato</a>
          </nav>
          
          <div className="flex items-center space-x-4">
            <button className="btn-secondary">Login</button>
            <button className="btn-primary">Demonstração</button>
          </div>
        </div>
      </div>
    </header>
  );
};

// Hero Section Component
const HeroSection = () => {
  return (
    <section className="bg-gradient-hero pt-20 section-padding">
      <div className="container-custom">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="animate-fade-in-up">
            <h1 className="text-hero text-gradient-primary mb-6">
              Transforme sua Frota em um Ecossistema Sustentável
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              Segurança Veicular + Blockchain + ESG. Monitore, certifique e tokenize 
              o impacto ambiental da sua frota com tecnologia de ponta.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <button className="btn-primary flex items-center justify-center space-x-2">
                <span>Solicitar Demonstração</span>
                <ArrowRight className="h-5 w-5" />
              </button>
              <button className="btn-secondary flex items-center justify-center space-x-2">
                <Play className="h-5 w-5" />
                <span>Ver Vídeo</span>
              </button>
            </div>
            
            {/* Métricas em Tempo Real */}
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-gradient-primary">2.4t</div>
                <div className="text-sm text-gray-600">CO₂ Evitado</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gradient-primary">1,247</div>
                <div className="text-sm text-gray-600">Tokens Gerados</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gradient-primary">23</div>
                <div className="text-sm text-gray-600">Frotas Ativas</div>
              </div>
            </div>
          </div>
          
          <div className="animate-slide-in-right">
            <div className="relative">
              <div className="bg-white rounded-2xl shadow-2xl p-6 animate-float">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">Dashboard ESG</h3>
                  <div className="flex space-x-2">
                    <div className="w-3 h-3 bg-red-400 rounded-full"></div>
                    <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                    <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="card-metric">
                    <Leaf className="h-8 w-8 text-green-500 mb-2" />
                    <div className="text-2xl font-bold">94%</div>
                    <div className="text-sm text-gray-600">Eficiência</div>
                  </div>
                  <div className="card-metric">
                    <Coins className="h-8 w-8 text-orange-500 mb-2" />
                    <div className="text-2xl font-bold">+15</div>
                    <div className="text-sm text-gray-600">Tokens Hoje</div>
                  </div>
                </div>
                
                <div className="h-32 bg-gradient-to-r from-green-100 to-blue-100 rounded-lg flex items-center justify-center">
                  <BarChart3 className="h-16 w-16 text-green-500 animate-pulse-custom" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

// Features Section Component
const FeaturesSection = () => {
  const features = [
    {
      icon: Shield,
      title: "Segurança Verificável",
      description: "Monitoramento em tempo real com sensores avançados e verificação externa via blockchain."
    },
    {
      icon: Leaf,
      title: "Sustentabilidade ESG",
      description: "Métricas ambientais certificadas seguindo padrões GRI, SASB e TCFD."
    },
    {
      icon: Coins,
      title: "Tokenização Blockchain",
      description: "Converta impacto positivo em tokens negociáveis e certificações verificáveis."
    },
    {
      icon: Truck,
      title: "Gestão de Frotas",
      description: "Controle completo da sua frota com dashboards inteligentes e relatórios automatizados."
    },
    {
      icon: BarChart3,
      title: "Analytics Avançado",
      description: "Inteligência artificial para otimização de rotas e predição de manutenções."
    },
    {
      icon: Lock,
      title: "Segurança Máxima",
      description: "Criptografia end-to-end e arquitetura desenvolvida em Rust para máxima segurança."
    }
  ];

  return (
    <section id="features" className="section-padding bg-gray-50">
      <div className="container-custom">
        <div className="text-center mb-16">
          <h2 className="text-section-title text-gradient-secondary mb-4">
            Recursos Principais
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Uma plataforma completa que integra segurança veicular, sustentabilidade 
            e tecnologia blockchain para revolucionar a gestão de frotas.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="card p-6 animate-fade-in-up" style={{animationDelay: `${index * 0.1}s`}}>
              <feature.icon className="h-12 w-12 text-blue-600 mb-4" />
              <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

// How It Works Section
const HowItWorksSection = () => {
  const steps = [
    {
      number: "01",
      title: "Instalação",
      description: "Instalação rápida do dispositivo GuardDrive em seus veículos com ativação via QR Code.",
      icon: Zap
    },
    {
      number: "02", 
      title: "Monitoramento",
      description: "Coleta automática de dados de segurança, emissões e comportamento de condução.",
      icon: BarChart3
    },
    {
      number: "03",
      title: "Tokenização",
      description: "Conversão automática de métricas ESG positivas em tokens blockchain verificáveis.",
      icon: Coins
    }
  ];

  return (
    <section className="section-padding">
      <div className="container-custom">
        <div className="text-center mb-16">
          <h2 className="text-section-title text-gradient-primary mb-4">
            Como Funciona
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Três passos simples para transformar sua frota em um ecossistema sustentável e certificado.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="text-center animate-fade-in-up" style={{animationDelay: `${index * 0.2}s`}}>
              <div className="relative mb-6">
                <div className="w-20 h-20 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <step.icon className="h-10 w-10 text-white" />
                </div>
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                  {step.number}
                </div>
              </div>
              <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Benefits Section
const BenefitsSection = () => {
  const benefits = [
    {
      icon: TrendingUp,
      title: "Redução de Custos",
      description: "Até 30% de economia em combustível e manutenção através de otimização inteligente."
    },
    {
      icon: Award,
      title: "Certificações ESG",
      description: "Certificações automáticas que atendem aos principais frameworks internacionais."
    },
    {
      icon: Globe,
      title: "Impacto Global",
      description: "Contribua para metas globais de sustentabilidade e mudanças climáticas."
    },
    {
      icon: Users,
      title: "Engajamento",
      description: "Gamificação que motiva condutores a adotar práticas mais sustentáveis."
    }
  ];

  return (
    <section id="benefits" className="section-padding bg-gradient-secondary text-white">
      <div className="container-custom">
        <div className="text-center mb-16">
          <h2 className="text-section-title mb-4">
            Benefícios Comprovados
          </h2>
          <p className="text-xl opacity-90 max-w-3xl mx-auto">
            Resultados mensuráveis que impactam positivamente seu negócio e o meio ambiente.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {benefits.map((benefit, index) => (
            <div key={index} className="text-center animate-fade-in-up" style={{animationDelay: `${index * 0.1}s`}}>
              <benefit.icon className="h-12 w-12 text-orange-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-3">{benefit.title}</h3>
              <p className="opacity-90">{benefit.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Pricing Section
const PricingSection = () => {
  const plans = [
    {
      name: "Starter",
      price: "R$ 99",
      period: "/mês",
      description: "Ideal para pequenas frotas",
      features: [
        "Até 10 veículos",
        "Dashboard básico",
        "Relatórios mensais",
        "Suporte por email",
        "Tokenização básica"
      ],
      popular: false
    },
    {
      name: "Professional",
      price: "R$ 299",
      period: "/mês",
      description: "Para frotas em crescimento",
      features: [
        "Até 100 veículos",
        "Dashboard avançado",
        "Relatórios em tempo real",
        "Suporte prioritário",
        "Tokenização completa",
        "API personalizada"
      ],
      popular: true
    },
    {
      name: "Enterprise",
      price: "Customizado",
      period: "",
      description: "Para grandes operações",
      features: [
        "Veículos ilimitados",
        "Dashboard personalizado",
        "Relatórios customizados",
        "Suporte dedicado",
        "Blockchain privada",
        "Integração completa"
      ],
      popular: false
    }
  ];

  return (
    <section id="pricing" className="section-padding bg-gray-50">
      <div className="container-custom">
        <div className="text-center mb-16">
          <h2 className="text-section-title text-gradient-primary mb-4">
            Planos e Preços
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Escolha o plano ideal para sua frota. Todos incluem tokenização ESG e certificações blockchain.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div key={index} className={`card p-8 relative ${plan.popular ? 'ring-2 ring-blue-500 scale-105' : ''}`}>
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-blue-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                    Mais Popular
                  </span>
                </div>
              )}
              
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <div className="text-4xl font-bold text-gradient-primary mb-2">
                  {plan.price}
                  <span className="text-lg text-gray-600">{plan.period}</span>
                </div>
                <p className="text-gray-600">{plan.description}</p>
              </div>
              
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-500" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              
              <button className={`w-full ${plan.popular ? 'btn-primary' : 'btn-secondary'}`}>
                Começar Agora
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Testimonials Section
const TestimonialsSection = () => {
  const testimonials = [
    {
      name: "Carlos Silva",
      position: "Diretor de Sustentabilidade",
      company: "LogiTrans",
      content: "O GuardDrive transformou nossa operação. Reduzimos 25% das emissões e ainda geramos receita com tokens ESG.",
      rating: 5
    },
    {
      name: "Ana Costa",
      position: "Gerente de Frotas",
      company: "EcoDelivery",
      content: "A plataforma é intuitiva e os relatórios ESG nos ajudaram a conseguir certificações importantes.",
      rating: 5
    },
    {
      name: "Roberto Santos",
      position: "CEO",
      company: "GreenLogistics",
      content: "Investimento que se paga. A economia em combustível e os tokens ESG compensam o custo rapidamente.",
      rating: 5
    }
  ];

  return (
    <section className="section-padding">
      <div className="container-custom">
        <div className="text-center mb-16">
          <h2 className="text-section-title text-gradient-secondary mb-4">
            O que nossos clientes dizem
          </h2>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="card p-6">
              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-gray-600 mb-6 italic">"{testimo
(Content truncated due to size limit. Use line ranges to read in chunks)